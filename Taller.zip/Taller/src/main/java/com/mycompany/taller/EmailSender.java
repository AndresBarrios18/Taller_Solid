
package com.mycompany.taller;

public class EmailSender {
    
    
    public static void sendEmail(Interfaz_Contacto c, String message){
        
        String emailAddress = c.getEmailAddress();
        
    }
}
