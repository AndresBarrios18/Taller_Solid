/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taller;

/**
 *
 * @author sala8
 */

    public class SMSSender {
    

    public static void sendSMS(Interfaz_Contacto c,String message){
        
        String telephone = c.getTelephone();
        
    }
   
}
